import os
import shutil
import time
import logging
from pathlib import Path
import json

logging.basicConfig(filename='autosort.log', level=logging.INFO, format='%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

with open('config.json', 'r') as config_file:
    config = json.load(config_file)
source_folder = config['source_folder']
destination_folders = config['destination_folders']

for folder in destination_folders.values():
    os.makedirs(os.path.join(source_folder, folder), exist_ok=True)

def get_destination_folder(file_extension):
    for folder, extensions in destination_folders.items():
        if file_extension.lower() in extensions:
            return folder
    return "Miscellaneous"

def sort_item(item_path, item_name):
    if Path(item_path).is_file():
        destination_folder = get_destination_folder(os.path.splitext(item_name)[-1])
    else:
        destination_folder = "Archives"
    destination_path = os.path.join(source_folder, destination_folder, item_name)
    try:
        shutil.move(item_path, destination_path)
        logging.info(f"Moved {item_name} to {destination_folder} folder.")
    except Exception as e:
        logging.error(f"Error moving {item_name} to {destination_folder} folder: {e}")

def monitor_folder():
    logging.info("Monitoring folder...")
    while True:
        time.sleep(5)
        for item in os.listdir(source_folder):
            sort_item(os.path.join(source_folder, item), item)

if __name__ == "__main__":
    monitor_folder()
